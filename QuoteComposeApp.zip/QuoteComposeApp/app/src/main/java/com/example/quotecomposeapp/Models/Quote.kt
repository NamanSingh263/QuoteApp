package com.example.quotecomposeapp.Models

data class Quote( val text: String, val author: String) {
}